<?php

include '../classes/User.php';

$user = new user;

$user->logout();



?>

