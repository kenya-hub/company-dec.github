<?php

include '../classes/Product.php';

$product = new Product ;

$product->storeProduct($_POST);

?>